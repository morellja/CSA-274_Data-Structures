#include <string>
#using <mscorlib.dll>
using namespace std;
using namespace System;

void MarshalString ( String ^ s, string& os );

